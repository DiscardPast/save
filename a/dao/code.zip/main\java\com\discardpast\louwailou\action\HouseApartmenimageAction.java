package com.discardpast.louwailou.action;

/**
 * @apiNote 房屋信息图片表(HouseApartmenimage)业务逻辑服务类
 * @author discardpast@yeah.net
 * @since 2019-10-31 11:59:36
 */
@Component
public class HouseApartmenimageAction{
}
