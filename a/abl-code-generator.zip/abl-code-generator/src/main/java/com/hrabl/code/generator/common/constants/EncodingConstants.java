package com.hrabl.code.generator.common.constants;

/**
 * @author baohua.yin@qq.com
 * @apiNote 字符集常量
 * @since 2019/5/4 23:21
 */
public interface EncodingConstants {
    String Utf8 = "UTF-8";
}
