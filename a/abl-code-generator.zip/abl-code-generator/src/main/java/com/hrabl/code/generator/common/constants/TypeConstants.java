package com.hrabl.code.generator.common.constants;

/**
 * @author baohua.yin@qq.com
 * @apiNote 类型常量
 * @since 2019/5/4 22:23
 */
public interface TypeConstants {
    String Mysql = "Mysql";
    String Oracle = "Oracle";
}
